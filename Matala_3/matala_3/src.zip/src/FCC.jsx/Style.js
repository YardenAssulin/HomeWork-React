import { Button, styled } from '@mui/material'
import styledEngineSc from '@mui/styled-engine-sc';

export const PinkButton = styled(Button)({
    backgroundColor: "pink",
    color: "black",
    margin: 2,
    "&:hover": {
      backgroundColor: "pink",
      color: "white"
    },

  });


