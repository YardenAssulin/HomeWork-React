import { useState, useEffect } from 'react';
import {logoutUser} from './storage'
import { useNavigate } from 'react-router-dom';
import EditProfile from './EditProfile';

const Profile = ({setIsloggedin}) => {
    const [user, setUser] = useState({});
    const [showEdit, setShowEdit] = useState(false);

    const navigate = useNavigate();
    useEffect(() => {
        const rawUser = sessionStorage.getItem("login");
        if (rawUser) {
            const user = JSON.parse(rawUser);
            setUser(user)
        }else{
            navigate('/')
        }
    }, [])

    const updateUser = (newUserData) => {
        setUser(newUserData);
      };

    const toggleShowEdit = () => {
        setShowEdit(!showEdit)
    }

    const onLogout = () => {
        const logoutSuccess = logoutUser(user.email);{
            if(logoutSuccess){
                setIsloggedin(false);
              navigate("/")  ;
            }
        }
    }
    return (
        <div>   
        <div style={{ display: 'flex' }}>
            <img src="./images/WhatsApp Image 2024-03-04 at 14.28.14.jpeg" alt="profile picture" />
            <div>
                <h3>{user.firstName} {user.lastName}</h3>
                <p>{user.email}</p>
                <p>{user.street} {user.streetNum}, {user.city}</p>
                <p>{new Date(user.birthDate).toLocaleDateString()}</p>
                <div>
                    <button onClick={toggleShowEdit}>עדכון פרטים</button>
                    <a href=""><button>מעבר למשחק</button></a>
                    <button onClick={onLogout}>התנתק</button>
                </div>
            </div>
        </div>
        {showEdit === true && <EditProfile user={user} updateUser={updateUser}/>}
        </div>
    )
}

export default Profile;