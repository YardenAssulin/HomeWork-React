import {useEffect, useState} from 'react';
import {loadUsers, saveUsers, adminEditUser} from './storage';
import EditProfile from './EditProfile'

function SystemAdmin () {
    const [registeredUsers, setRegisteredUsers] = useState([]);
    const [selectedUser, setSelectedUser] = useState(null)

    useEffect(() => {
        onLoadUsers()
    }, [])

    const deleteUser = (email) => {
        const tempUsers = registeredUsers.filter(u => u.email !== email) ;
        setRegisteredUsers(tempUsers)
        saveUsers(tempUsers)
    }
    const toggleShowEdit = (user) => {
        setSelectedUser(user)
    }

    const onLoadUsers = () => {
        const users = loadUsers();
        setRegisteredUsers(users)
    }

    return(
        <div>
            <table style={{direction:'rtl'}}>
                <thead>
                    <tr>
                        <th>שם משתמש</th>
                        <th>שם מלא</th>
                        <th>תאריך לידה</th>
                        <th>כתובת</th>
                        <th>דואר אלקטרוני</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    {

                        registeredUsers.map( u => {
                            return (
                                <tr key={u.email}>
                                    <td>{u.username}</td>
                                    <td>{u.firstName + " " + u.lastName}</td>
                                    <td>{new Date(u.birthDate).toLocaleString()}</td>
                                    <td>{`${u.street} ${u.streetNum}, ${u.city}`}</td>
                                    <td>{u.email}</td>
                                    <td><button onClick={()=>deleteUser(u.email)}>delete</button><button onClick={()=>toggleShowEdit(u)}>edit</button></td>
                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>
            {selectedUser !== null && <EditProfile user={selectedUser} updateUser={onLoadUsers} adminEditUser={adminEditUser}/>}
        </div>
    )

}

export default SystemAdmin;